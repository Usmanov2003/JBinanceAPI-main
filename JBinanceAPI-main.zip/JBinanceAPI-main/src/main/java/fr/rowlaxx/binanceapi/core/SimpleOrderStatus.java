package fr.rowlaxx.binanceapi.core;

public interface SimpleOrderStatus {

}
