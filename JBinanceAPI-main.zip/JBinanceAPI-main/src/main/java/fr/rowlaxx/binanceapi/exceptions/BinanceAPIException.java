package fr.rowlaxx.binanceapi.exceptions;

public class BinanceAPIException extends BinanceException {
	private static final long serialVersionUID = 25661446321357741L;

	public BinanceAPIException(String msg) {
		super(msg);
	}
	
}
