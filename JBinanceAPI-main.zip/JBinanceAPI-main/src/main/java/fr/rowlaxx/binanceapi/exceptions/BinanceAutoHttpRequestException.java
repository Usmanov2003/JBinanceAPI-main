package fr.rowlaxx.binanceapi.exceptions;

public class BinanceAutoHttpRequestException extends BinanceException {
	private static final long serialVersionUID = -5653935642362669487L;

	public BinanceAutoHttpRequestException(String msg) {
		super(msg);
	}
	
}
