package fr.rowlaxx.binanceapi.core.futuresalgo;

public enum AlgoTypes {

	VP;
	
}
