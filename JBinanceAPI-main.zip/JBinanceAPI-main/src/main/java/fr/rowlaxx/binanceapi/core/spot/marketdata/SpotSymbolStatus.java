package fr.rowlaxx.binanceapi.core.spot.marketdata;

public enum SpotSymbolStatus {
	
	PRE_TRADING,
	TRADING,
	POST_TRADING,
	END_OF_DAY,
	HALT,
	AUCTION_MATCH,
	BREAK;

}
