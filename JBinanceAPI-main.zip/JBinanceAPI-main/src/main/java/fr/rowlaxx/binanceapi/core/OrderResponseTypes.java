package fr.rowlaxx.binanceapi.core;

public enum OrderResponseTypes {

	ACK,
	RESULT,
	FULL
	
}
