package fr.rowlaxx.binanceapi.core.usdm.marketdata;

public enum UsdmFuturesType {
	
	U_MARGINED
	
}