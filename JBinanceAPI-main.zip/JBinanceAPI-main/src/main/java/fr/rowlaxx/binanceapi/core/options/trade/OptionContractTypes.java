package fr.rowlaxx.binanceapi.core.options.trade;

public enum OptionContractTypes {

	CALL,
	PUT
	
}
