package fr.rowlaxx.binanceapi.core.staking;

public enum TxnTypes {

	SUBSCRIPTION,
	REDEMPTION,
	INTEREST;
	
}
