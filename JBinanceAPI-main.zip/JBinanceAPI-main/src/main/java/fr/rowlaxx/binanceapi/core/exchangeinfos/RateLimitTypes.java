package fr.rowlaxx.binanceapi.core.exchangeinfos;

public enum RateLimitTypes {

	ORDERS,
	REQUEST_WEIGHT,
	RAW_REQUESTS;
	
}
