package fr.rowlaxx.binanceapi.core.futures.marketdata;

public enum UnderlyingTypes {
	
	INDEX,
	COIN;

}
