package fr.rowlaxx.binanceapi.core.options.trade;

public enum FundsTransferTypes {

	IN, OUT
	
}
