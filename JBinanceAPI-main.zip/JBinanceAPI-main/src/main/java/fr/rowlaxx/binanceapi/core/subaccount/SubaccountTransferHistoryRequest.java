package fr.rowlaxx.binanceapi.core.subaccount;

import fr.rowlaxx.binanceapi.core.wallet.TransferHistoryRequest;

public class SubaccountTransferHistoryRequest extends TransferHistoryRequest {

	public String email;
	
}
