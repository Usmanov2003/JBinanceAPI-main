package fr.rowlaxx.binanceapi.core.bswap;

public enum LiquidityOperationTypes {

	SINGLE,
	COMBINATION
	
}
