package fr.rowlaxx.binanceapi.core.subaccount;

public enum AccountTypes {

	SPOT,
	USDT_FUTURES,
	COIN_FUTURES,
	MARGIN,
	ISOLATED_MARGIN;
	
}
