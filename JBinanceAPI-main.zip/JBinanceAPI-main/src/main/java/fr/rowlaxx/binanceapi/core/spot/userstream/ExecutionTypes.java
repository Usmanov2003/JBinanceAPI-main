package fr.rowlaxx.binanceapi.core.spot.userstream;

public enum ExecutionTypes {

	NEW, CANCELED, REPLACED, REJECTED, TRADE, EXPIRED;
	
}
