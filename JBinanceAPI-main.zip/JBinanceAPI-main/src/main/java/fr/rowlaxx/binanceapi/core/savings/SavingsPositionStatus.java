package fr.rowlaxx.binanceapi.core.savings;

public enum SavingsPositionStatus {

	HOLDING,
	REDEEMED;
	
}
