package fr.rowlaxx.binanceapi.exceptions;

public class FilterInstanciationException extends BinanceException {

	private static final long serialVersionUID = -4273760847189549916L;

	public FilterInstanciationException(Throwable cause) {
		super(cause);
	}
	
}
