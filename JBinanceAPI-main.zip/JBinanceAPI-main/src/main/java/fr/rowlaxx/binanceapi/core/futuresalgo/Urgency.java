package fr.rowlaxx.binanceapi.core.futuresalgo;

public enum Urgency {

	LOW,
	MEDIUM,
	HIGH;
	
}
