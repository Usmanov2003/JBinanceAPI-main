package fr.rowlaxx.binanceapi.core.futures.trade;

public enum WorkingType {

	MARK_PRICE,
	CONTRACT_PRICE;
	
}
