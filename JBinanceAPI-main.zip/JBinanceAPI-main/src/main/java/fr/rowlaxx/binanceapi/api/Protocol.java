package fr.rowlaxx.binanceapi.api;

public enum Protocol {

	WEBSOCKET,
	HTTPS
	
}
