package fr.rowlaxx.binanceapi.core.portfoliomargin;

public enum AccountStatus {

	NORMAL, MARGIN_CALL, SUPPLY_MARGIN, REDUCE_ONLY, ACTIVE_LIQUIDATION, FORCE_LIQUIDATION, BANKRUPTED;
	
}
