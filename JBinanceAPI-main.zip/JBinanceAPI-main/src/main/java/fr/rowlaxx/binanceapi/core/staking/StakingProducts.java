package fr.rowlaxx.binanceapi.core.staking;

public enum StakingProducts {

	STAKING,
	F_DEFI,
	L_DEFI;
	
}
