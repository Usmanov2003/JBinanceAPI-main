package fr.rowlaxx.binanceapi.api;

public enum Platform {

	SPOT,
	USDM,
	COINM,
	OPTIONS;
	
}
