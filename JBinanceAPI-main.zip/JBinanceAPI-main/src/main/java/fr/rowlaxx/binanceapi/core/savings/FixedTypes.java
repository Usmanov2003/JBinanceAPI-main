package fr.rowlaxx.binanceapi.core.savings;

public enum FixedTypes {

	ACTIVITY,
	CUSTOMIZED_FIXED;
	
}
