package fr.rowlaxx.binanceapi.core.futuresalgo;

public enum AlgoStatus {

	WORKING,
	CANCELLED,
	
}
