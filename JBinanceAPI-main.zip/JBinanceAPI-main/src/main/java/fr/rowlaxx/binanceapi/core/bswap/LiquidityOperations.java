package fr.rowlaxx.binanceapi.core.bswap;

public enum LiquidityOperations {
	
	ADD,
	REMOVE

}
