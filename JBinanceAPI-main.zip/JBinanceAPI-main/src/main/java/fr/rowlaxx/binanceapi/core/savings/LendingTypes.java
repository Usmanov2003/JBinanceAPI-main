package fr.rowlaxx.binanceapi.core.savings;

public enum LendingTypes {

	DAILY,
	ACTIVITY,
	CUSTOMIZED_FIXED;
	
}
