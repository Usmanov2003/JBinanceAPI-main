package fr.rowlaxx.binanceapi.core.exchangeinfos;

public enum RateLimitIntervals {

	SECOND,
	MINUTE,
	DAY;
	
}
