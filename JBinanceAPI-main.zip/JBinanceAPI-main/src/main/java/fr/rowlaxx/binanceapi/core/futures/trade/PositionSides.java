package fr.rowlaxx.binanceapi.core.futures.trade;

public enum PositionSides {

	BOTH,
	LONG,
	SHORT
	
}
