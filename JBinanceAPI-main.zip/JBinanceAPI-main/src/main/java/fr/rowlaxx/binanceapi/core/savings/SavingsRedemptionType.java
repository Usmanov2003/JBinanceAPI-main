package fr.rowlaxx.binanceapi.core.savings;

public enum SavingsRedemptionType {

	FAST,
	NORMAL;
	
}
