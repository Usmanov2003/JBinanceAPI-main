package fr.rowlaxx.binanceapi.core.savings;

public enum SavingsStatus {

	ALL,
	SUBSCRIBABLE,
	UNSUBSCRIBABLE;
	
}
