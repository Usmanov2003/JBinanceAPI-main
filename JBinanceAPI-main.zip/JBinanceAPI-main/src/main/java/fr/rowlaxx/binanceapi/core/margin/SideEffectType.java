package fr.rowlaxx.binanceapi.core.margin;

public enum SideEffectType {

	NO_SIDE_EFFECT,
	MARGIN_BUY,
	AUTO_REPAY;
	
}
