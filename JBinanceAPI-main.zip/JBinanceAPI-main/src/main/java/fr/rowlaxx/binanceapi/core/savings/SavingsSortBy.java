package fr.rowlaxx.binanceapi.core.savings;

public enum SavingsSortBy {
	
	START_TIME,
	LOT_SIZE,
	INTEREST_RATE,
	DURATION

}
