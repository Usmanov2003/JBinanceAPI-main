package fr.rowlaxx.binanceapi.exceptions;

public class BinanceClientImplementerException extends BinanceException {
	private static final long serialVersionUID = 2826521889271325006L;

	public BinanceClientImplementerException(String msg) {
		super(msg);
	}

}
