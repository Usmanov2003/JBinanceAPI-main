package fr.rowlaxx.binanceapi.core.wallet;

public enum TransferType {

	WITHDRAW,
	DEPOSIT;
}
