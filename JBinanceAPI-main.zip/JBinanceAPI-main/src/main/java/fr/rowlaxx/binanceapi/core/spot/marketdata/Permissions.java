package fr.rowlaxx.binanceapi.core.spot.marketdata;

public enum Permissions {

	SPOT,
	MARGIN,
	LEVERAGED,
	TRD_GRP_003
	
}
