package fr.rowlaxx.binanceapi.core.subaccount;

public enum TransferStatus {

	SUCCESS;
	
}
