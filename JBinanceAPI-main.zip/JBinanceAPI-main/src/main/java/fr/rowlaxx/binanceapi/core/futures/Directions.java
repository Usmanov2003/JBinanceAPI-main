package fr.rowlaxx.binanceapi.core.futures;

public enum Directions {

	ADDITIONAL,
	REDUCED
	
}
