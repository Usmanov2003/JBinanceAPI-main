package fr.rowlaxx.binanceapi.core;

public enum TimeInForce {

	GTC,
	IOC,
	FOK,
	GTX
	
}
