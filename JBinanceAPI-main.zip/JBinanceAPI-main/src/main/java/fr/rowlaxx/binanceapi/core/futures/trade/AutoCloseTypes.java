package fr.rowlaxx.binanceapi.core.futures.trade;

public enum AutoCloseTypes {

	LIQUIDATION,
	ADL
	
}
