package fr.rowlaxx.binanceapi.client.websocket;

import org.json.JSONObject;

public interface OnJson {

	public void onJson(JSONObject json);
	
}
